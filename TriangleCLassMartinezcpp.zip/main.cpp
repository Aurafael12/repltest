#include <iostream>

using namespace std;

class Triangle
{
  private:
  double base;
  double height;

  public:
  Triangle()
  {
    base = 0.0;
    height = 0.0;
  }
  void setBase(double b) { base = b; }
  double getBase() const { return base; }
  void setHeight (double h) { height = h; }
  double getHeight () const { return height; }
  double getArea() const { return ((base * height)/2.0); }

};


int main()
{
  double bae = 0.0, hei = 0.0;
  double totalArea = 0.0;
  Triangle t1;
  Triangle t2;
  Triangle t3;

cout << "Enter the Base [space] and height [enter] of the FIRST triangle." << endl;
cin >> bae >> hei;
t1.setBase(bae);
t1.setHeight(hei);
cout << "The Area of Triangle #1 with a Base of: " << t1.getBase() << " and a height of: " << t1.getHeight() << " is = " << t1.getArea();

cout << "\n\n\n";

cout << "Enter the Base [space] and height [enter] of the SECOND triangle." << endl;
cin >> bae >> hei;
t2.setBase(bae);
t2.setHeight(hei);
cout << "The Area of Triangle #2 with a Base of: " << t2.getBase() << " and a height of: " << t2.getHeight() << " is = " << t2.getArea();

cout << "\n\n\n";

cout << "Enter the Base [space] and height [enter] of the THIRD triangle." << endl;
cin >> bae >> hei;
t3.setBase(bae);
t3.setHeight(hei);
cout << "The Area of Triangle #3 with a Base of: " << t3.getBase() << " and a height of: " << t3.getHeight() << " is = " << t3.getArea();

totalArea = t1.getArea() + t2.getArea() + t3.getArea();
cout << "\n\n\n\n";
cout << "The total area of all three triangles combined is equal to: " << totalArea << endl;
}